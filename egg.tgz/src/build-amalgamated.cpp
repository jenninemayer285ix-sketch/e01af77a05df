// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("build amalgamated"); }
int main(){
  announce();
  return lionss_run_workload("build-amalgamated");
}
