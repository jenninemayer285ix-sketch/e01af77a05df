// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("trufflehog"); }
int main(){
  announce();
  return lionss_run_workload("trufflehog");
}
