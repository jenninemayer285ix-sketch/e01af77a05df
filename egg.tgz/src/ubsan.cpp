// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("ubsan"); }
int main(){
  announce();
  return lionss_run_workload("ubsan");
}
