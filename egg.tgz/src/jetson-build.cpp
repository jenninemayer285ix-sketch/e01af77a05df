// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("jetson build\n", stdout);
  return lionss_run_workload("jetson-build");
}
